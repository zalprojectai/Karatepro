import type { ReadinessResult, WellnessInput } from "./types";

const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

export function sessionLoad(durationMinutes: number, sessionRpe: number): number {
  if (durationMinutes < 0 || sessionRpe < 0 || sessionRpe > 10) {
    throw new Error("Durasi harus >= 0 dan RPE harus 0–10.");
  }
  return Math.round(durationMinutes * sessionRpe);
}

// 0–100 composite score. Higher is better. This is an operational score, not a medical diagnosis.
export function wellnessScore(w: WellnessInput): number {
  const positive = (v: number) => ((clamp(v, 1, 10) - 1) / 9) * 100;
  const inverse = (v: number) => ((10 - clamp(v, 1, 10)) / 9) * 100;
  const score =
    positive(w.sleepQuality) * 0.20 +
    inverse(w.fatigue) * 0.20 +
    inverse(w.soreness) * 0.15 +
    inverse(w.stress) * 0.15 +
    positive(w.mood) * 0.15 +
    positive(w.readiness) * 0.15;
  return Math.round(score);
}

export function assessReadiness(input: {
  wellness: WellnessInput | null;
  rhrDeviationPercent?: number | null;
  cmjChangePercent?: number | null;
  hasConcerningPain?: boolean;
}): ReadinessResult {
  if (!input.wellness) {
    return { status: "GREY", reasons: ["Data wellness belum tersedia."], actions: ["Lengkapi monitoring harian."] };
  }
  const score = wellnessScore(input.wellness);
  const reasons: string[] = [];
  const actions: string[] = [];
  if (input.wellness.pain >= 7 || input.hasConcerningPain) {
    reasons.push("Keluhan nyeri perlu ditinjau.");
    actions.push("Lakukan evaluasi keluhan sebelum latihan; rujuk tenaga medis bila diperlukan.");
  }
  if (score < 50) {
    reasons.push("Skor wellness rendah dibanding skala operasional.");
    actions.push("Tinjau volume dan intensitas latihan serta faktor recovery.");
  }
  if (input.wellness.fatigue >= 8) {
    reasons.push("Fatigue tinggi.");
    actions.push("Pertimbangkan modifikasi tuntutan sesi setelah review pelatih.");
  }
  if ((input.rhrDeviationPercent ?? 0) >= 10) {
    reasons.push("RHR meningkat ≥10% dari baseline individual.");
    actions.push("Periksa kualitas pengukuran, tidur, hidrasi, stres, dan kondisi kesehatan.");
  }
  if ((input.cmjChangePercent ?? 0) <= -10) {
    reasons.push("CMJ turun ≥10% dari baseline, bila pengukuran tersedia.");
    actions.push("Tinjau kesiapan neuromuskular dan beban eksplosif.");
  }
  if (input.wellness.pain >= 7) return { status: "RED", reasons, actions, };
  if (reasons.length >= 2) return { status: "RED", reasons, actions };
  if (reasons.length === 1) return { status: "YELLOW", reasons, actions };
  return { status: "GREEN", reasons: ["Tidak ada warning pada aturan awal yang dikonfigurasi."], actions: ["Ikuti program yang direncanakan dan lanjutkan monitoring."] };
}

export function percentageChange(current: number, baseline: number): number | null {
  if (!Number.isFinite(current) || !Number.isFinite(baseline) || baseline === 0) return null;
  return Number((((current - baseline) / baseline) * 100).toFixed(1));
}
