import { useMemo, useState } from "react";
import { Activity, Users, ClipboardCheck, HeartPulse, Dumbbell, ChartNoAxesCombined, ShieldAlert, Settings, Search, Bell, Plus, ArrowUpRight, CheckCircle2, AlertTriangle, CircleHelp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line } from "recharts";
import { assessReadiness, sessionLoad, wellnessScore } from "./calculations";
import { isFirebaseConfigured } from "./firebase";
import type { Athlete, WellnessInput } from "./types";

const initialAthletes: Athlete[] = [
  { id: "A-001", fullName: "Atlet Contoh 01", athleteCode: "MRZ-001", discipline: "KUMITE", competitionLevel: "Elite", weightCategory: "-67 kg", status: "ACTIVE" },
  { id: "A-002", fullName: "Atlet Contoh 02", athleteCode: "MRZ-002", discipline: "KATA", competitionLevel: "International", weightCategory: "Individual", status: "ACTIVE" },
  { id: "A-003", fullName: "Atlet Contoh 03", athleteCode: "MRZ-003", discipline: "KUMITE", competitionLevel: "Elite", weightCategory: "-75 kg", status: "ACTIVE" },
];
const weekly = [{day:"Mon",load:520},{day:"Tue",load:680},{day:"Wed",load:410},{day:"Thu",load:720},{day:"Fri",load:810},{day:"Sat",load:240},{day:"Sun",load:0}];
const trend = [{day:"Mon",wellness:82,rhr:55},{day:"Tue",wellness:78,rhr:57},{day:"Wed",wellness:74,rhr:58},{day:"Thu",wellness:69,rhr:61},{day:"Fri",wellness:76,rhr:57},{day:"Sat",wellness:85,rhr:54},{day:"Sun",wellness:88,rhr:53}];
const nav = [
  { label: "Overview", icon: ChartNoAxesCombined },
  { label: "Athlete Management", icon: Users },
  { label: "Daily Monitoring", icon: HeartPulse },
  { label: "Physical Assessment", icon: ClipboardCheck },
  { label: "Training Load", icon: Activity },
  { label: "Programs", icon: Dumbbell },
  { label: "Injury & Recovery", icon: ShieldAlert },
];

export default function App() {
  const [active, setActive] = useState("Overview");
  const [athletes, setAthletes] = useState(initialAthletes);
  const [query, setQuery] = useState("");
  const [showWellness, setShowWellness] = useState(false);
  const [selectedAthlete, setSelectedAthlete] = useState("A-001");
  const [wellness, setWellness] = useState<WellnessInput>({ sleepQuality:7, fatigue:3, soreness:3, stress:3, mood:8, readiness:8, pain:0 });
  const [savedMessage, setSavedMessage] = useState("");
  const filtered = useMemo(() => athletes.filter(a => a.fullName.toLowerCase().includes(query.toLowerCase()) || a.athleteCode.toLowerCase().includes(query.toLowerCase())), [athletes, query]);
  const readiness = assessReadiness({ wellness });
  const score = wellnessScore(wellness);
  const totalLoad = weekly.reduce((s, d) => s + d.load, 0);

  const addAthlete = () => {
    const n = athletes.length + 1;
    setAthletes([...athletes, { id: `A-00${n}`, fullName: `New Athlete ${n}`, athleteCode: `MRZ-00${n}`, discipline: "KUMITE", competitionLevel: "Elite", weightCategory: "Not set", status: "ACTIVE" }]);
  };

  const saveWellnessDemo = () => {
    setSavedMessage("Data demo berhasil divalidasi di tampilan ini. Hubungkan Firebase untuk penyimpanan permanen.");
    setShowWellness(false);
  };

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">MRZ</div><div><strong>HIGH PERFORMANCE</strong><span>KARATE SYSTEM</span></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <div className="workspace"><span className="workspace-dot"/> Elite Karate Team <span className="chevron">⌄</span></div>
      <div className="nav-label">MAIN MENU</div>
      {nav.map(item => <button key={item.label} className={`nav-item ${active===item.label?"active":""}`} onClick={()=>setActive(item.label)}><item.icon size={17}/><span>{item.label}</span>{item.label==="Daily Monitoring" && <i className="nav-dot"/>}</button>)}
      <div className="sidebar-bottom"><button className="nav-item" onClick={()=>setActive("Settings")}><Settings size={17}/>Settings</button><div className="coach-mini"><div className="avatar">C</div><div><b>Coach Account</b><small>Performance Staff</small></div><span>•••</span></div></div>
    </aside>

    <main className="main">
      <header className="topbar"><div className="breadcrumb">MRZ / <b>{active}</b></div><div className="top-actions"><span className={`connection ${isFirebaseConfigured?"connected":""}`}><i/> {isFirebaseConfigured?"Firebase configured":"Demo mode"}</span><button className="icon-btn"><Bell size={18}/></button><div className="avatar">C</div></div></header>
      <section className="page">
        <div className="page-heading"><div><div className="eyebrow">PERFORMANCE MANAGEMENT / 2026 SEASON</div><h1>{active==="Overview"?"Performance Overview":active}</h1><p>Monitor, analyze, and optimize elite karate athlete performance.</p></div><button className="primary-btn" onClick={()=>setShowWellness(true)}><Plus size={16}/> Daily Wellness</button></div>
        {savedMessage && <div className="notice"><CheckCircle2 size={16}/>{savedMessage}<button onClick={()=>setSavedMessage("")}>×</button></div>}
        {active==="Overview" && <>
          <div className="stat-grid">
            <Stat title="Active Athletes" value={String(athletes.length).padStart(2,"0")} note="Across Kumite & Kata" icon={<Users/>}/>
            <Stat title="Wellness Completion" value="92%" note="Today · Demo data" icon={<HeartPulse/>}/>
            <Stat title="Weekly Training Load" value={`${(totalLoad/1000).toFixed(2)}k`} note="AU · Current week" icon={<Activity/>}/>
            <Stat title="Coach Review" value="02" note="Require attention · Demo" icon={<ShieldAlert/>}/>
          </div>
          <div className="grid-two">
            <div className="panel"><PanelTitle title="Weekly Training Load" sub="Session RPE × duration · Arbitrary Units"/><div className="chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={weekly}><CartesianGrid strokeDasharray="3 3" stroke="#263348"/><XAxis dataKey="day" stroke="#8391a5"/><YAxis stroke="#8391a5"/><Tooltip contentStyle={{background:"#111c2d",border:"1px solid #2a3a52",borderRadius:10}}/><Bar dataKey="load" fill="#4d9cff" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div></div>
            <div className="panel"><PanelTitle title="Wellness Trend" sub="Composite score · 0–100 · Demo data"/><div className="chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={trend}><CartesianGrid strokeDasharray="3 3" stroke="#263348"/><XAxis dataKey="day" stroke="#8391a5"/><YAxis domain={[0,100]} stroke="#8391a5"/><Tooltip contentStyle={{background:"#111c2d",border:"1px solid #2a3a52",borderRadius:10}}/><Line type="monotone" dataKey="wellness" stroke="#36c99a" strokeWidth={3} dot={{r:3}}/></LineChart></ResponsiveContainer></div></div>
          </div>
          <div className="grid-two bottom-grid">
            <div className="panel"><PanelTitle title="Athlete Overview" sub="Roster and specialization"/><div className="search"><Search size={15}/><input placeholder="Search athlete..." value={query} onChange={e=>setQuery(e.target.value)}/></div><AthleteTable athletes={filtered}/><button className="text-btn" onClick={()=>setActive("Athlete Management")}>View all athletes <ArrowUpRight size={14}/></button></div>
            <div className="panel"><PanelTitle title="Readiness Snapshot" sub="Illustrative coaching status"/><div className="readiness-card"><div className="readiness-score">{score}<small>/100</small></div><div><b className={`status ${readiness.status.toLowerCase()}`}>{readiness.status}</b><p>Example athlete · {readiness.reasons[0]}</p></div></div><div className="mini-row"><span>Sleep quality</span><b>{wellness.sleepQuality}/10</b></div><div className="mini-row"><span>Fatigue</span><b>{wellness.fatigue}/10</b></div><div className="mini-row"><span>Reported pain</span><b>{wellness.pain}/10</b></div><button className="secondary-btn full" onClick={()=>setShowWellness(true)}>Open wellness form</button></div>
          </div>
        </>}
        {active==="Athlete Management" && <div className="panel"><div className="panel-head"><PanelTitle title="Athlete Roster" sub="Manage Kumite and Kata athletes"/><button className="primary-btn" onClick={addAthlete}><Plus size={15}/> Add demo athlete</button></div><div className="search"><Search size={15}/><input placeholder="Search athlete..." value={query} onChange={e=>setQuery(e.target.value)}/></div><AthleteTable athletes={filtered}/><p className="muted small">Demo action only: roster changes are held in browser memory until Firebase is connected.</p></div>}
        {active==="Daily Monitoring" && <div className="panel"><PanelTitle title="Daily Wellness Monitoring" sub="Athlete self-report and readiness screening"/><button className="primary-btn" onClick={()=>setShowWellness(true)}><Plus size={15}/> Enter wellness</button><div className="table-wrap"><table><thead><tr><th>ATHLETE</th><th>SLEEP</th><th>FATIGUE</th><th>SORENESS</th><th>PAIN</th><th>STATUS</th></tr></thead><tbody>{athletes.map(a=><tr key={a.id}><td>{a.fullName}</td><td>7/10</td><td>3/10</td><td>3/10</td><td>0/10</td><td><span className="status green">GREEN</span></td></tr>)}</tbody></table></div></div>}
        {active==="Physical Assessment" && <div className="panel"><PanelTitle title="Physical Assessment Library" sub="Core tests configured for Kumite and Kata"/><div className="test-grid">{[["10 m Sprint","Acceleration","seconds","Both"],["20 m Sprint","Speed","seconds","Both"],["4 × 9 m Shuttle Run","Change of direction","seconds","Kumite"],["T-Test","Agility","seconds","Both"],["Sideward Leg Splits","Hip flexibility","cm / degrees","Both"],["Knee-to-Wall","Ankle mobility","cm","Both"],["20 m Shuttle Run","Aerobic capacity","level / meters","Both"],["Single Leg Balance","Postural control","seconds","Kata"]].map(t=><div className="test-card" key={t[0]}><div className="test-icon"><ClipboardCheck size={18}/></div><b>{t[0]}</b><span>{t[1]}</span><small>{t[2]} · {t[3]}</small><button onClick={()=>setSavedMessage(`${t[0]} selected. Assessment form/database integration is the next implementation step.`)}>Open protocol <ArrowUpRight size={13}/></button></div>)}</div></div>}
        {active==="Training Load" && <div className="panel"><PanelTitle title="Training Load Calculator" sub="Session RPE × duration"/><LoadCalculator/></div>}
        {active==="Programs" && <div className="panel"><PanelTitle title="Training Programs" sub="Kumite and Kata program management"/><div className="empty-state"><Dumbbell size={28}/><b>Program module scaffold</b><p>Next implementation: exercise library, weekly calendar, sets, reps, intensity, rest, athlete assignment and session completion.</p></div></div>}
        {active==="Injury & Recovery" && <div className="panel"><PanelTitle title="Injury & Recovery" sub="Pain reporting, availability and return-to-training"/><div className="empty-state"><ShieldAlert size={28}/><b>Injury tracking scaffold</b><p>Record body area, pain score, onset, impact on movement, medical review and return-to-training status.</p></div></div>}
        {active==="Settings" && <div className="panel"><PanelTitle title="System Settings" sub="Firebase and application configuration"/><div className="notice"><CircleHelp size={16}/>Firebase status: {isFirebaseConfigured?"Environment variables detected.":"Not configured. Add Firebase environment variables and deploy Firestore rules."}</div><p className="muted">Demo mode is active until Firebase Authentication, Firestore collections, and security rules are configured.</p></div>}
        <footer>MRZ HIGH PERFORMANCE <span>·</span> KARATE ATHLETE MANAGEMENT <span>·</span> V1.0 STARTER</footer>
      </section>
    </main>
    {showWellness && <div className="modal-backdrop" onClick={()=>setShowWellness(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">ATHLETE MONITORING</div><h2>Daily Wellness</h2></div><button className="icon-btn" onClick={()=>setShowWellness(false)}>×</button></div><label>Athlete<select value={selectedAthlete} onChange={e=>setSelectedAthlete(e.target.value)}>{athletes.map(a=><option key={a.id} value={a.id}>{a.fullName}</option>)}</select></label>{([["Sleep Quality","sleepQuality"],["Fatigue","fatigue"],["Muscle Soreness","soreness"],["Stress","stress"],["Mood","mood"],["Perceived Readiness","readiness"]] as const).map(([label,key])=><label className="range-label" key={key}><span>{label}<b>{wellness[key]}/10</b></span><input type="range" min="1" max="10" value={wellness[key]} onChange={e=>setWellness({...wellness,[key]:Number(e.target.value)})}/></label>)}<label className="range-label"><span>Pain score <b>{wellness.pain}/10</b></span><input type="range" min="0" max="10" value={wellness.pain} onChange={e=>setWellness({...wellness,pain:Number(e.target.value)})}/></label><div className="modal-result"><span>Calculated wellness score</span><strong>{score}/100</strong><span className={`status ${readiness.status.toLowerCase()}`}>{readiness.status}</span></div><button className="primary-btn full" onClick={saveWellnessDemo}>Validate demo entry</button><p className="muted tiny">This starter validates calculations locally. Connect Firebase before storing real athlete data.</p></div></div>}
  </div>;
}

function Stat({title,value,note,icon}:{title:string;value:string;note:string;icon:React.ReactNode}) {
  return <div className="stat-card"><div className="stat-top"><span>{title}</span><div className="stat-icon">{icon}</div></div><strong>{value}</strong><small>{note}</small></div>;
}
function PanelTitle({title,sub}:{title:string;sub:string}) { return <div className="panel-title"><div><h3>{title}</h3><p>{sub}</p></div><button className="more-btn">•••</button></div>; }
function AthleteTable({athletes}:{athletes:Athlete[]}) {
  return <div className="table-wrap"><table><thead><tr><th>ATHLETE</th><th>CODE</th><th>SPECIALIZATION</th><th>LEVEL</th><th>STATUS</th></tr></thead><tbody>{athletes.map(a=><tr key={a.id}><td><div className="athlete-cell"><div className="athlete-avatar">{a.fullName.slice(0,1)}</div><b>{a.fullName}</b></div></td><td>{a.athleteCode}</td><td><span className="discipline">{a.discipline}</span></td><td>{a.competitionLevel}</td><td><span className="status green">ACTIVE</span></td></tr>)}</tbody></table></div>;
}
function LoadCalculator() {
  const [duration,setDuration] = useState(90);
  const [rpe,setRpe] = useState(7);
  const load = sessionLoad(duration,rpe);
  return <div className="calculator"><label>Duration (minutes)<input type="number" min="0" value={duration} onChange={e=>setDuration(Number(e.target.value))}/></label><label>Session RPE (0–10)<input type="number" min="0" max="10" step=".5" value={rpe} onChange={e=>setRpe(Number(e.target.value))}/></label><div className="load-result"><span>Calculated session load</span><strong>{load} <small>AU</small></strong><code>{duration} min × RPE {rpe}</code></div><p className="muted small">Illustrative calculation. Persist to Firestore after Firebase setup.</p></div>;
}
