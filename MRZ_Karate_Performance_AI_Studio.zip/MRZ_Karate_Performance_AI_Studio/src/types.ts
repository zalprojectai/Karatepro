export type Discipline = "KUMITE" | "KATA" | "BOTH";
export type ReadinessStatus = "GREEN" | "YELLOW" | "RED" | "GREY";

export interface Athlete {
  id: string;
  fullName: string;
  athleteCode: string;
  discipline: Discipline;
  competitionLevel: string;
  weightCategory: string;
  status: "ACTIVE" | "INACTIVE";
}

export interface WellnessInput {
  sleepQuality: number;
  fatigue: number;
  soreness: number;
  stress: number;
  mood: number;
  readiness: number;
  pain: number;
}

export interface ReadinessResult {
  status: ReadinessStatus;
  reasons: string[];
  actions: string[];
}
