# MASTER BUILD PROMPT — MRZ KARATE PERFORMANCE

Build and complete a production-oriented full-stack web application named **MRZ Karate Performance** for elite/international karate athletes in both Kumite and Kata.

## Product requirements
- Language: Indonesian UI, English sport-science terms where conventional.
- Brand: MRZ High Performance.
- Visual: premium dark navy/charcoal sport-science dashboard, restrained electric-blue accents, responsive desktop/tablet/mobile.
- Roles: COACH and ATHLETE.
- Backend: Firebase Authentication + Cloud Firestore. Use server-side privileged operations only where necessary. Never expose secrets in client code.
- Deploy target: Google AI Studio Build mode and Cloud Run.

## Critical implementation rules
1. Do not leave buttons as decorative controls. Every visible action must work or be clearly disabled with an explanation.
2. Replace all demo data with Firestore-backed data once Firebase is configured.
3. Keep demo/seed data clearly labeled and never mix it with real athlete data.
4. Implement secure role-based access. A user must not be able to self-assign COACH role. Provision coach role through a trusted admin/server process.
5. Enforce athlete ownership and coach-athlete assignment in Firestore rules and server-side validation.
6. Add loading, empty, error, success, validation and permission-denied states.
7. Do not invent athlete measurements, norms, or test results. Unmeasured results must be NOT_TESTED.
8. Readiness labels are coaching-support signals, not medical diagnoses and must never autonomously clear an athlete for competition.
9. Add audit trail for coach edits and recommendations.
10. Add automated tests for calculation functions, permissions, and critical forms.

## Main modules
A. Authentication & onboarding
- Email/password and Google Sign-In.
- Role-based routing.
- Coach creates/invites athletes; athletes cannot select coach role.
- User profile, password reset, session handling.

B. Coach portal
- Overview KPIs: active athletes, Kumite/Kata distribution, wellness completion, weekly load, coach reviews.
- Athlete roster, search, filters, athlete profile, coach assignment.
- Daily monitoring table and alerts.
- Assessment calendar and physical test entry.
- Training program builder and calendar.
- Injury/recovery tracking.
- Individual reports and CSV/PDF export.

C. Athlete portal
- Today's wellness form.
- Assigned training plan.
- Session completion and session RPE.
- Personal test history and performance charts.
- Injury/pain reporting.
- Coach feedback and notifications.

D. Athlete specialization
- KUMITE, KATA, BOTH.
- Kumite emphasis: acceleration, speed, reaction, change of direction, repeated high-intensity capacity, aerobic recovery.
- Kata emphasis: strength, explosive power, balance, postural control, hip/ankle mobility, movement quality.
- Shared tests must not imply identical norms between disciplines.

E. Physical assessment
Create versioned test catalog with instructions, setup, warm-up, trials, recovery, units, best-result direction, equipment, validity notes and discipline tags.
Core available equipment: smartwatch/HR monitor, stopwatch/timing gate, flexibility measurement tools.
Tests:
- 10 m sprint
- 20 m sprint
- 4 × 9 m shuttle run (Kumite-specific option)
- T-test
- visual reaction test (only if a standardized validated protocol/device is defined)
- sideward leg split (store measurement method: distance or angle)
- sit-and-reach
- knee-to-wall ankle dorsiflexion
- single-leg balance
- 20 m shuttle run (store level, shuttle, total distance, protocol version; label VO2max as estimated)
Optional future equipment tests: CMJ, 1RM squat, medicine ball throw, Wingate, dynamometry.
Store every trial, best/mean, units, test protocol version, assessor, date, conditions and data quality. Do not compare manual stopwatch results directly with timing-gate results without a method warning.

F. Daily monitoring
- Wellness scale 1–10: sleep quality, fatigue, muscle soreness, stress, mood, perceived readiness.
- Pain scale 0–10, location, notes, training impact.
- Sleep duration.
- RHR; HR/HR zones during sessions; HR recovery only under a defined standardized protocol; HRV only if device provides it.
- Body mass optional.
- Post-session duration and session RPE (CR10), entered consistently after session.
- Missing data remains missing, never auto-filled with zero.

G. Training load calculations
- Session load = duration minutes × session RPE, unit AU.
- Daily load = sum of session loads per local athlete date.
- Weekly load = sum over a clearly defined 7-day period.
- Optional ACWR: document chosen rolling or coupled method, window definitions and limitations. Never present ACWR as an injury prediction or standalone clearance threshold.
- Preserve raw inputs and calculation version.

H. Analytics
- Wellness trend, RHR trend, HRV trend if available, training load trend, session category breakdown, physical test progression, baseline comparison.
- Radar chart only after values are normalized using appropriate discipline/age/sex/category references or explicitly labeled individual progress indices.
- Show raw values alongside normalized values.
- Mark estimated values and data-quality limitations.

I. Recommendation engine
- Rule-based, transparent, configurable thresholds.
- Inputs: wellness, RHR deviation from individual baseline, optional HRV, pain, CMJ if measured, training load, injury status, competition calendar.
- Status: GREEN, YELLOW, RED, GREY (insufficient data).
- Every alert must display the exact triggering indicators and the recommended coach review.
- Pain/injury concerns trigger review; do not diagnose.
- Coach must approve and record training modifications. No automatic medical or competition clearance.
- Thresholds must be configurable and labeled provisional until calibrated against longitudinal athlete data.

## Firestore data model
Implement collections with documented schemas and indexes:
- users
- athleteProfiles
- coachProfiles
- coachAthletes
- wellnessRecords
- vitalRecords
- wearableRecords
- physicalTestCatalog
- assessmentSessions
- testResults
- trainingPrograms
- trainingSessions
- sessionCompletions
- trainingLoadRecords
- injuryRecords
- recoveryRecords
- readinessRecords
- recommendations
- competitionCalendar
- notifications
- auditLogs

Use server timestamps, immutable record IDs, createdBy/updatedBy, athleteId, source/device metadata, units, protocolVersion, and dataQuality fields where relevant. Add Firestore security rules and emulator tests for role/ownership boundaries.

## API and validation
- Validate all numeric ranges and required fields server-side.
- Use transactions/batched writes where consistency is needed.
- Prevent duplicate daily wellness submissions or provide a versioned edit flow.
- Store dates with timezone-aware timestamps and calculate athlete-local training dates correctly.
- Add pagination for roster and records.
- Add export endpoint with access checks.
- Never put admin credentials or service account keys in the browser.

## Acceptance criteria
- Coach and athlete can sign in and see different portals.
- Coach can add/assign an athlete.
- Athlete can submit wellness and post-session RPE.
- Coach can view the submission immediately.
- Session load calculations match test cases.
- Coach can create assessment session and record multiple trials.
- Athlete can view only own data.
- Coach can view only assigned athletes.
- Charts use actual database data and show empty states when no data exists.
- Every alert shows its reason and can be reviewed/approved by coach.
- Build, typecheck and tests pass.
- Provide README with Firebase setup, environment variables, deployment, backup and security instructions.

First inspect the imported codebase. Preserve the existing visual direction where useful, then implement the missing backend, auth, Firestore persistence, role security, test coverage and functional workflows. Do not claim production readiness until all acceptance criteria and security tests pass.
