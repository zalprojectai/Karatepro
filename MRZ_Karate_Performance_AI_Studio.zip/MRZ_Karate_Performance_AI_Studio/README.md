# MRZ Karate Performance — Google AI Studio Starter

Starter project untuk membangun MRZ Karate Performance (Kumite + Kata) dengan React, TypeScript, Firebase Authentication, dan Cloud Firestore.

## Isi paket
- React + Vite + TypeScript responsive dashboard
- Coach dashboard dan modul navigasi awal
- Roster demo Kumite/Kata
- Daily Wellness demo form
- Session RPE × duration calculator
- Wellness composite score dan readiness rules (starter rules, bukan diagnosis)
- Physical assessment test library starter
- Firebase client initialization
- Firestore security rules starter

## Penting: status implementasi
Paket ini adalah **starter/MVP UI + calculation scaffold**, bukan sistem produksi yang sudah selesai. Saat pertama dibuka, aplikasi berjalan dalam demo mode dan menggunakan data contoh di memori browser. Form demo belum menyimpan data ke Firestore. Firebase Authentication, Firestore CRUD per modul, wearable APIs, audit logs, dan production hardening harus diselesaikan sebelum data atlet sungguhan digunakan.

## Jalankan lokal
1. Install Node.js 20 atau lebih baru.
2. Extract ZIP.
3. Jalankan:
   ```bash
   npm install
   npm run dev
   ```
4. Buka URL lokal yang ditampilkan Vite.

## Firebase setup
1. Buat project Firebase.
2. Aktifkan Authentication (Email/Password dan/atau Google Sign-In).
3. Buat Cloud Firestore.
4. Salin `.env.example` menjadi `.env.local`, lalu isi konfigurasi Firebase Web App.
5. Deploy rules:
   ```bash
   firebase deploy --only firestore:rules
   ```
6. Buat dokumen `users/{uid}` dengan role `COACH` atau `ATHLETE` melalui proses admin tepercaya. Jangan izinkan pengguna memilih role coach sendiri dari halaman registrasi.
7. Buat dokumen relasi `coachAthletes/{coachUid}_{athleteId}` untuk penugasan coach.

**Security note:** rules yang disertakan adalah starter dan perlu diuji serta diperketat. Untuk produksi, implementasikan custom claims/admin provisioning, validasi schema, ownership check per collection, dan emulator security tests. Jangan menyimpan data kesehatan atlet sebelum kebijakan akses dan privasi disetujui.

## Google AI Studio
Google AI Studio Build mode mendukung aplikasi web full-stack, impor proyek dari GitHub, dan ekspor ZIP. Cara yang paling aman:
1. Extract ZIP ini.
2. Upload folder ke GitHub repository.
3. Di Google AI Studio > Build mode > Add files (+) > Import from GitHub.
4. Pilih repository.
5. Gunakan `GOOGLE_AI_STUDIO_BUILD_PROMPT.md` sebagai prompt lanjutan untuk meminta agent menyelesaikan integrasi Firebase dan modul produksi.
6. Uji di preview, jalankan test, lalu gunakan Publish untuk deploy ke Cloud Run.

Alternatif: mulai aplikasi baru di AI Studio Build mode dan tempel prompt lengkap di `GOOGLE_AI_STUDIO_BUILD_PROMPT.md`. Minta AI Studio membuat React + Node.js full-stack app dan mengaktifkan Firebase Authentication + Cloud Firestore.

## Rumus awal
- Session load = duration minutes × session RPE.
- Wellness score = weighted 0–100 composite, arah skor dinormalisasi.
- Readiness GREEN/YELLOW/RED/GREY = rule-based operational flag, bukan diagnosis atau keputusan medis otomatis.

## Sebelum produksi
- Ganti seluruh data demo.
- Lengkapi CRUD dan validasi backend.
- Tambahkan audit logs dan role security tests.
- Kalibrasi thresholds readiness dengan data individual dan staf medis.
- Validasi protokol tes dan reliabilitas pengukuran.
- Integrasikan wearable hanya melalui API resmi / export yang diizinkan.
- Tambahkan backup, retention policy, consent, dan incident response.
